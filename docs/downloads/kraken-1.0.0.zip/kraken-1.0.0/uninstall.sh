#!/usr/bin/env bash

docker-compose down

rm -rf data
sudo rm -rf analysis